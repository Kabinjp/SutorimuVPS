<?php
session_start();

if(isset($_GET['logout'])){
    session_destroy();
    header('Location: index.php');
    exit();
}

if(!isset($_SESSION['authorized'])){

if(isset($_POST['submit'])){
    if($_POST['username'] =='sutorimu' && $_POST['password'] == 'SUTORIMUVPSPASSWORD'){
        $_SESSION['authorized'] = true;
        header('Location: index.php');
        exit();
    }else {
		$ERROR = '<div id="login-status" class="error-notice" style="visibility: visible">
            <div id="login-detail">
                <div id="login-status-icon-container"><span class="login-status-icon"></span></div>
                <div id="login-status-message">El inicio de sesi�n no es v�lido.</div>
            </div>
        </div>';
		}
}

?>
<!DOCTYPE html>
<html dir="ltr">
<head>
    <meta http-equiv="Content-Type" content="text/html;" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="google" content="notranslate" />
    <title>Inicio de sesi�n Afrodita</title>
    <link rel="shortcut icon" href="/cpanel/favicon.ico" />

    <!-- EXTERNAL CSS -->
    <link href="/cpanel/fonts/open-sans/open_sans.min.css" rel="stylesheet" type="text/css" />
    <link href="/cpanel/style_v2_optimized.css" rel="stylesheet" type="text/css" />
</head>
<body class="whm">


<div id="login-wrapper">
    <div id="notify">

	<?php if (isset($ERROR)) echo $ERROR ?>
    
        <div id='login-status' class="error-notice" style="visibility: hidden">
            <div id="login-detail">
                <div id="login-status-icon-container"><span class='login-status-icon'></span></div>
                <div id="login-status-message">Ha cerrado la sesi�n.</div>
            </div>
        </div>
    </div>

    <div id="content-container">
        <div id="login-container">
            <div id="login-sub-container">
                <div id="login-sub-header">
                    <img src="/cpanel/images/whm-white.png" alt="logo" />
                </div>
                <div id="login-sub">
                    <div id="forms">

                        
                        <form novalidate id="login_form" action="" method="post" target="_top" autocomplete='off'>
                            <div class="input-req-login"><label for="user">Nombre de usuario</label></div>
                            <div class="input-field-login icon username-container">
                                <input name="username" autofocus value="" placeholder="Introduzca su nombre de usuario." class="std_textbox" type="text"  tabindex="1" required>
                            </div>
                            <div style="margin-top:30px;" class="input-req-login"><label for="pass">Contrase�a</label></div>
                            <div class="input-field-login icon password-container">
                                <input name="password" placeholder="Introduzca la contrase�a de su cuenta." class="std_textbox" type="password" tabindex="2"  required>
                            </div>
                            <div class="controls">
                                <div class="login-btn">
                                    <button type="submit" name="submit" tabindex="3">Iniciar sesi�n</button>
                                </div>

                                                            </div>
                            <div class="clear" id="push"></div>
                        </form>

                    <!--CLOSE forms -->
                    </div>

                <!--CLOSE login-sub -->
                </div>
            <!--CLOSE login-sub-container -->
            </div>
        <!--CLOSE login-container -->
        </div>

        <div id="locale-footer">
            <div class="locale-container">

            </div>
        </div>
    </div>
<!--Close login-wrapper -->
</div>

    <div class="copyright">Copyright� <?=date("Y")?> Afrodita, Inc.</div>

</body>

</html>

<?php } else { ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>File Manager for web</title>

		<!-- jQuery and jQuery UI (REQUIRED) -->
		<link rel="stylesheet" type="text/css" href="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
        <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Ubuntu:bold&amp;v1" />
        <link rel="shortcut icon" type="image/x-icon" href="/favicon.ico">
        <link rel="stylesheet" type="text/css" href="/stylesheets/default.css" />
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>

		<!-- elFinder CSS (REQUIRED) -->
		<link rel="stylesheet" type="text/css" href="css/elfinder.min.css">
		<link rel="stylesheet" type="text/css" media="screen" href="windows-10/css/theme.css">

		<!-- elFinder JS (REQUIRED) -->
		<script src="js/elfinder.min.js"></script>

		<!-- elFinder Basic Auth JS -->
		<script src="js/elfinderBasicAuth.js"></script>

		<!-- elFinder translation (OPTIONAL) -->
		

		<!-- elFinder initialization (REQUIRED) -->
   <script type="text/javascript">
      // disable HTML quicklook plugin
      elFinder.prototype.commands.quicklook.plugins[1] = null;
      $().ready(function() {
        if (typeof document.uniqueID != 'undefined') {
          (function(){
            var xhr = new XMLHttpRequest();
            if (!('withCredentials' in xhr)) {
                $('<script>').attr('src', './demo/xdr/jquery.xdr.js').appendTo('head');
            }
            xhr = null;
          })();
        }
        var getLang = function() {
          try {
            var full_lng;
            var loct = window.location.search;
            var locm;
            if (loct && (locm = loct.match(/lang=([a-zA-Z_-]+)/))) {
              full_lng = locm[1];
            } else {
              full_lng = (navigator.browserLanguage || navigator.language || navigator.userLanguage);
            }
            var lng = full_lng.substr(0,2);
            if (lng == 'ja') lng = 'jp';
            else if (lng == 'pt') lng = 'pt_BR';
            else if (lng == 'zh') lng = (full_lng.substr(0,5) == 'zh-tw')? 'zh_TW' : 'zh_CN';

            if (lng != 'en') {
              var script_tag      = document.createElement("script");
              script_tag.type     = "text/javascript";
              script_tag.src      = "js/i18n/elfinder."+lng+".js";
              script_tag.charset = "utf-8";
              $("head").append(script_tag);
            }

            return lng;
          } catch(e) {
            return 'en';
          }
        };
			// Documentation for client options:
			// https://github.com/Studio-42/elFinder/wiki/Client-configuration-options
			var f = $('#elfinder').elfinder({
					url : 'php/connector.minimal.php',  // connector URL (REQUIRED)
					 lang: getLang()
				}).elfinder('instance');
			});
		</script>
	</head>
	<body>
    <div class="wrap">
      <div class="header clearfix">
        <div class="logo">
        <a href="/"><img src="/img/logo.png" alt="elFinder logo" /></a>
        <h1><a href="/">Hosutingu <span>file manager for web</span></a></h1>
        </div>
      </div>

      <div class="content">

		<!-- Element where elFinder will be created (REQUIRED) -->
		<div id="elfinder"></div>
        
      </div>

      <div class="footer">
        <img src="img/vintage.png" alt="" /><br/>
        <?php
		if( $_SESSION['authorized'] == true){
		echo '<a href="http://hosutingu.gq">Hosutingu</a><br/><p><a href="?logout">Logout</a></p>';	
		}
		else
		{
			echo '<a href="http://sutorimu.ga">Sutorimu.ga</a>';
		}
		?>
      </div>
    </div>

	</body>
</html>
<?php } ?>